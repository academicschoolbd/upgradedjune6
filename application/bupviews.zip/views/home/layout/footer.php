<!--================================
							footer-section-start
                      ===============================-->
    <div class="footer-section">
        <div class="container">
            <div class="footer_color">
                <div class="row">
                    <div class="elitesDesign-3 elitesDesign-m2">          
                        <div class="footer_wrpp">
						                            <div class="footer-menu-title">
                                ফুটার মেনু                            </div>
						                                <div class="footer-menu">
                                <div class="menu-footer-menu-one-container"><ul id="menu-footer-menu-one" class="menu"><li id="menu-item-215" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-215"><i class="las la-plus"></i> <a href="<?php echo base_url('frontend/about'); ?>">প্রতিষ্ঠানের ইতিহাস</a></li>
<li id="menu-item-217" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-217"><i class="las la-plus"></i> <a href="<?php echo base_url('frontend/contact'); ?>">যোগাযোগ</a></li>
<li id="menu-item-220" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-220"><i class="las la-plus"></i> <a href="<?php echo base_url('frontend/terms'); ?>">ট্রামস অ্যান্ড কন্ডিশন</a></li>
<li id="menu-item-220" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-220"><i class="las la-plus"></i> <a href="<?php echo base_url('frontend/privacy'); ?>">প্রাইভেসি অ্যান্ড পলিসি</a></li>
</ul></div>                            </div>
                        </div>
                    </div>
                    <div class="elitesDesign-3 elitesDesign-m2">   
                        <div class="footer_wrpp">
						                            <div class="footer-menu-title">
                                    ফুটার মেনু                            </div>
							                        
                            <div class="footer-menu">
                                <div class="menu-footer-menu-two-container"><ul id="menu-footer-menu-two" class="menu"><li id="menu-item-221" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-221"><i class="las la-plus"></i> <a href="<?php echo base_url('frontend/exam_results'); ?>">পরীক্ষার ফলাফল</a></li>
<li id="menu-item-222" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-222"><i class="las la-plus"></i> <a href="<?php echo base_url('frontend/news'); ?>">নোটিশ</a></li>
<li id="menu-item-220" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-220"><i class="las la-plus"></i> <a href="<?php echo base_url('frontend/gallery'); ?>">ফটো গ্যালারী</a></li>
<li id="menu-item-220" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-220"><i class="las la-plus"></i> <a href="<?php echo base_url('frontend/video'); ?>">ভিডিও গ্যালারী</a></li>
</ul></div>
                            </div>
                        </div>   
                    </div>   
                    
                    <div class="elitesDesign-3 elitesDesign-m1">   
                        <div class="footer_wrpp">
							                            <div class="footer-menu-title">
                               যোগাযোগের ঠিকানা                            </div>
							
                            							<div class="f-address-content">
                                <div class="footer-icon">
                                    <i class="la la-map-marker-alt"></i>
                                </div>                                 
                                  <?php echo $cms_setting['address']; ?>                </div>
							
                            							<div class="f-address-content">
                                <div class="footer-icon">
                                    <i class="la la-phone"></i>
                                </div>
                              <?php echo $cms_setting['mobile_no']; ?>                     </div>
							

                            							<div class="f-address-content">
                                <div class="footer-icon">
                                    <i class="lar la-envelope"></i>
                                </div>
                               <?php echo $cms_setting['email']; ?></div>
							
                            							<div class="f-address-content">
                                <div class="footer-icon">
                                    <i class="la la-star-half-alt"></i>
                                </div>
                                    ইআইআইএন নং :  <?php echo $cms_setting['eienn_code']; ?>                       </div>
							
                            							<div class="f-address-content">
                                <div class="footer-icon">
                                    <i class="la la-home"></i>
                                </div>
                                কলেজ কোড : <?php echo $cms_setting['college_code']; ?> 
                            </div>
							
                        </div>
                    </div>
                
                
                </div>
            </div>
            
        </div>
    </div>    
                        <!--================================
                              footer-section-End
                        ===============================--> 
                            
                             
                             
                             
        

     <!--================================
                              bottom-footer-start
                        ===============================-->
        <div class="bottom-footer-section footer_color">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                       <div class="copy-right">
                           <?php echo $cms_setting['copyright_text']; ?></div>
                       
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="design-developed">
সকল কারিগরী সহযোগিতায়ঃ  <a href='https://codedokan.com/' target='_blank' title='01303703990'>CodeDokan.Com</a></div>
                    </div>
                </div>
                
                <a href="#" class="elitesDesign_scroll"><i class="las la-level-up-alt"></i></a>
            </div>
        </div>
                        
                        
                        <!--================================
                              bottom-footer-End
                        ===============================-->
						
						<!-- JS Files -->
<script src="<?php echo base_url('assets/frontend/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/frontend/js/owl.carousel.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/frontend/plugins/shuffle/jquery.shuffle.modernizr.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/select2/js/select2.full.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/sweetalert/sweetalert.min.js');?>"></script>
<script src="<?php echo base_url('assets/frontend/plugins/magnific-popup/jquery.magnific-popup.min.js');?>"></script>
<script src="<?php echo base_url('assets/frontend/js/jquery.marquee.min.js');?>"></script>
<script src="<?php echo base_url('assets/frontend/js/custom.js'); ?>"></script>

<?php
$alertclass = "";
if($this->session->flashdata('alert-message-success')){
    $alertclass = "success";
} else if ($this->session->flashdata('alert-message-error')){
    $alertclass = "error";
} else if ($this->session->flashdata('alert-message-info')){
    $alertclass = "info";
}
if($alertclass != ''):
    $alert_message = $this->session->flashdata('alert-message-'. $alertclass);
?>
<script type="text/javascript">
    swal({
        toast: true,
        position: 'top-end',
        type: '<?php echo $alertclass?>',
        title: '<?php echo $alert_message?>',
        confirmButtonClass: 'btn btn-1',
        buttonsStyling: false,
        timer: 8000
    })
</script>
<?php endif; ?>
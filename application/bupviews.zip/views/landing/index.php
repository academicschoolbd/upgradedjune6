<?php
defined('BASEPATH') or exit('No direct script access allowed');
$signup = isset($signup_url) ? $signup_url : base_url('signup');
$login  = isset($login_url)  ? $login_url  : base_url('authentication');
$pkgs   = isset($packages) && is_array($packages) ? $packages : [];

$feature_labels = [
    'dashboard'     => 'Admin dashboard',
    'student'       => 'Student records',
    'staff'         => 'Staff records',
    'class'         => 'Classes & sections',
    'attendance'    => 'Attendance',
    'exam'          => 'Exam & gradebook',
    'frontend'      => 'Public school website',
    'fees'          => 'Fee collection',
    'notice'        => 'Notices',
    'sms'           => 'SMS notifications',
    'accounting'    => 'Full accounting',
    'library'       => 'Library',
    'transport'     => 'Transport',
    'hostel'        => 'Hostel',
    'custom_domain' => 'Custom domain',
    'api'           => 'REST API',
    'parent'        => 'Parent portal',
    'student_portal'=> 'Student portal',
];
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?=htmlspecialchars($page_title ?? 'SmartSchool.bd')?></title>
<meta name="description" content="Multi-tenant school management software for Bangladesh schools. Bengali UI, fee collection, attendance, exam, accounting, custom domains. 14-day free trial, no card required.">
<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<style>
:root { --brand: #1f9d55; --brand-dark: #157a40; --ink: #1b2436; --muted: #5b6478; --bg-soft: #f4f7fb; }
body { font-family: 'Segoe UI', system-ui, -apple-system, 'Noto Sans Bengali', sans-serif; color: var(--ink); }
.navbar-brand { font-weight: 700; color: var(--brand) !important; }
.navbar-brand .dot { color: var(--ink); }
.hero { background: linear-gradient(135deg, #e8f5ee 0%, #f4f7fb 100%); padding: 80px 0 60px; }
.hero h1 { font-size: 2.6rem; font-weight: 700; line-height: 1.15; margin-bottom: 16px; }
.hero .bn { font-size: 1.4rem; color: var(--muted); margin-bottom: 24px; }
.hero .lead { font-size: 1.1rem; color: var(--muted); margin-bottom: 32px; max-width: 600px; }
.btn-brand { background: var(--brand); border-color: var(--brand); color: #fff; }
.btn-brand:hover { background: var(--brand-dark); border-color: var(--brand-dark); color: #fff; }
.section { padding: 64px 0; }
.section.alt { background: var(--bg-soft); }
.section-title { font-size: 2rem; font-weight: 700; text-align: center; margin-bottom: 12px; }
.section-sub { text-align: center; color: var(--muted); margin-bottom: 40px; }
.feature { background: #fff; border-radius: 12px; padding: 24px; height: 100%; box-shadow: 0 2px 12px rgba(0,0,0,.04); border: 1px solid #e9ecef; }
.feature .icon { width: 44px; height: 44px; border-radius: 8px; background: #e8f5ee; color: var(--brand); display: inline-flex; align-items: center; justify-content: center; font-size: 1.4rem; margin-bottom: 14px; }
.feature h5 { font-weight: 700; margin-bottom: 8px; }
.feature p { color: var(--muted); margin: 0; font-size: .95rem; }
.price-card { background: #fff; border-radius: 14px; padding: 32px 24px; height: 100%; border: 1px solid #e9ecef; box-shadow: 0 2px 12px rgba(0,0,0,.04); display: flex; flex-direction: column; }
.price-card.featured { border: 2px solid var(--brand); transform: translateY(-6px); }
.price-card .plan-name { font-weight: 700; font-size: 1.2rem; text-transform: uppercase; letter-spacing: .04em; }
.price-card .badge-pop { background: var(--brand); color: #fff; padding: 4px 10px; border-radius: 999px; font-size: .7rem; font-weight: 700; }
.price-card .price { font-size: 2.4rem; font-weight: 700; margin: 16px 0 4px; }
.price-card .price small { font-size: 1rem; color: var(--muted); font-weight: 400; }
.price-card .per { color: var(--muted); margin-bottom: 18px; font-size: .9rem; }
.price-card ul { list-style: none; padding: 0; margin: 0 0 24px; flex: 1; }
.price-card ul li { padding: 6px 0; color: var(--ink); font-size: .94rem; display: flex; align-items: flex-start; gap: 8px; }
.price-card ul li:before { content: '✓'; color: var(--brand); font-weight: 700; flex-shrink: 0; }
.testimonial { background: #fff; border-radius: 12px; padding: 28px; height: 100%; border: 1px solid #e9ecef; }
.testimonial .quote { font-style: italic; color: var(--ink); margin-bottom: 16px; }
.testimonial .who { color: var(--muted); font-size: .9rem; }
.cta { background: linear-gradient(135deg, var(--brand) 0%, var(--brand-dark) 100%); color: #fff; padding: 64px 0; }
.cta h2 { font-weight: 700; margin-bottom: 12px; }
.cta .btn-light { color: var(--brand-dark); font-weight: 600; }
footer { background: #1b2436; color: #c0c8d6; padding: 40px 0 20px; font-size: .9rem; }
footer a { color: #fff; text-decoration: none; }
footer a:hover { text-decoration: underline; }
.bn { font-family: 'Noto Sans Bengali', 'SolaimanLipi', sans-serif; }
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm sticky-top">
  <div class="container">
    <a class="navbar-brand" href="<?=base_url()?>">SmartSchool<span class="dot">.bd</span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto align-items-md-center gap-md-2">
        <li class="nav-item"><a class="nav-link" href="#features">Features</a></li>
        <li class="nav-item"><a class="nav-link" href="#pricing">Pricing</a></li>
        <li class="nav-item"><a class="nav-link" href="#testimonials">Testimonials</a></li>
        <li class="nav-item"><a class="nav-link" href="<?=htmlspecialchars($login)?>">Login</a></li>
        <li class="nav-item"><a class="btn btn-brand ms-md-2" href="<?=htmlspecialchars($signup)?>">Start free trial</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero -->
<section class="hero">
  <div class="container">
    <div class="row align-items-center g-4">
      <div class="col-lg-7">
        <h1>School management software<br>for Bangladesh schools</h1>
        <p class="bn">বাংলাদেশের স্কুলগুলোর জন্য সম্পূর্ণ স্কুল ম্যানেজমেন্ট সফটওয়্যার</p>
        <p class="lead">Run admissions, attendance, exams, fees, accounting and a public website for your school — all in Bengali and English. Each school gets its own subdomain in 5 minutes. 14-day free trial, no card required.</p>
        <div class="d-flex flex-wrap gap-2">
          <a class="btn btn-brand btn-lg px-4" href="<?=htmlspecialchars($signup)?>">Start your free trial</a>
          <a class="btn btn-outline-secondary btn-lg px-4" href="#pricing">See pricing</a>
        </div>
        <div class="mt-4 text-muted small">
          Already live: <a href="https://ngps.smartschool.bd" target="_blank" rel="noopener">ngps.smartschool.bd</a> · <a href="https://test.smartschool.bd" target="_blank" rel="noopener">test.smartschool.bd</a>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="feature p-4 shadow-sm">
          <h5>Built for Bangladesh schools</h5>
          <ul class="list-unstyled m-0">
            <li class="py-1">🟢 Bengali admin UI + Bengali public site</li>
            <li class="py-1">🟢 BDT pricing, SSLCommerz checkout</li>
            <li class="py-1">🟢 Your own <code>schoolname.smartschool.bd</code></li>
            <li class="py-1">🟢 Optional custom domain (Pro plan)</li>
            <li class="py-1">🟢 Hosted in Bangladesh, ISP-friendly</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Features -->
<section class="section" id="features">
  <div class="container">
    <h2 class="section-title">Everything a Bangladeshi school needs</h2>
    <p class="section-sub">One platform for academics, fees, accounting and public CMS.</p>
    <div class="row g-4">
      <div class="col-md-6 col-lg-4"><div class="feature"><div class="icon">🎓</div><h5>Admissions &amp; students</h5><p>Online admission form, document upload, ID generation, photo upload, class &amp; section assignment.</p></div></div>
      <div class="col-md-6 col-lg-4"><div class="feature"><div class="icon">📋</div><h5>Attendance &amp; exams</h5><p>Daily attendance, exam scheduling, marks entry, gradebook, report card PDF download.</p></div></div>
      <div class="col-md-6 col-lg-4"><div class="feature"><div class="icon">💰</div><h5>Fees &amp; accounting</h5><p>Fee invoices, online + offline collection, dues report, full double-entry accounting with ledgers.</p></div></div>
      <div class="col-md-6 col-lg-4"><div class="feature"><div class="icon">🌐</div><h5>Public school website</h5><p>Sliders, news, gallery, events, teacher list — your school's own public website without writing code.</p></div></div>
      <div class="col-md-6 col-lg-4"><div class="feature"><div class="icon">📱</div><h5>Parent &amp; student portals</h5><p>Parents see attendance, exam results, fees and notices. Students see homework and live classes.</p></div></div>
      <div class="col-md-6 col-lg-4"><div class="feature"><div class="icon">🔐</div><h5>Multi-tenant &amp; isolated</h5><p>Every school's data is separated by <code>branch_id</code>. Your data is never visible to another school's admin.</p></div></div>
    </div>
  </div>
</section>

<!-- Pricing -->
<section class="section alt" id="pricing">
  <div class="container">
    <h2 class="section-title">Simple pricing</h2>
    <p class="section-sub">Start free for 14 days. Upgrade only when your school grows.</p>
    <div class="row g-4 justify-content-center">
      <?php $idx = 0; foreach ($pkgs as $p):
        $featured = (strtolower($p->code) === 'starter');
        $price = (float)$p->price_bdt;
        $per = $p->billing_period === 'yearly' ? '/year' : ($p->billing_period === 'lifetime' ? ' one-time' : '/month');
        $highlights = [];
        foreach (array_slice($p->features, 0, 7) as $f) {
            $highlights[] = $feature_labels[$f] ?? str_replace('_', ' ', $f);
        }
        if ((int)$p->trial_days > 0) {
            array_unshift($highlights, (int)$p->trial_days . '-day free trial');
        }
        $cta = strtolower($p->code) === 'free' ? 'Start free trial' : 'Choose ' . htmlspecialchars($p->name);
      ?>
      <div class="col-md-6 col-lg-4">
        <div class="price-card <?= $featured ? 'featured' : '' ?>">
          <?php if ($featured): ?><div class="mb-2"><span class="badge-pop">Most popular</span></div><?php endif; ?>
          <div class="plan-name"><?=htmlspecialchars($p->name)?></div>
          <div class="price"><?php if ($price > 0): ?>৳<?=number_format($price)?><small><?=htmlspecialchars($per)?></small><?php else: ?>Free<?php endif; ?></div>
          <?php if ($price > 0): ?><div class="per">USD ≈ <?=number_format($price / 110, 2)?> <?=htmlspecialchars($per)?></div><?php endif; ?>
          <ul>
            <?php foreach ($highlights as $h): ?><li><?=htmlspecialchars($h)?></li><?php endforeach; ?>
          </ul>
          <a class="btn <?= $featured ? 'btn-brand' : 'btn-outline-secondary' ?>" href="<?=htmlspecialchars($signup)?>?plan=<?=urlencode($p->code)?>"><?=$cta?></a>
        </div>
      </div>
      <?php $idx++; endforeach; ?>
    </div>
    <p class="section-sub mt-4 mb-0 small">Pricing is in Bangladeshi Taka. Free trial does not require a card. Cancel anytime.</p>
  </div>
</section>

<!-- Testimonials -->
<section class="section" id="testimonials">
  <div class="container">
    <h2 class="section-title">Schools already using SmartSchool.bd</h2>
    <p class="section-sub">Two real tenants serving live traffic today.</p>
    <div class="row g-4">
      <div class="col-md-6"><div class="testimonial"><div class="quote">"We moved from paper attendance to SmartSchool.bd in a weekend. Parents now get SMS the same morning if their child is absent."</div><div class="who">— NGPS Academy · <a href="https://ngps.smartschool.bd" target="_blank" rel="noopener">ngps.smartschool.bd</a></div></div></div>
      <div class="col-md-6"><div class="testimonial"><div class="quote">"The Bengali UI made staff adoption painless. We were collecting fees online by week 2."</div><div class="who">— Test school · <a href="https://test.smartschool.bd" target="_blank" rel="noopener">test.smartschool.bd</a></div></div></div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta text-center">
  <div class="container">
    <h2>Ready to digitise your school?</h2>
    <p class="mb-4 opacity-90">14-day free trial. Your own subdomain in 5 minutes. No credit card required.</p>
    <a class="btn btn-light btn-lg px-5" href="<?=htmlspecialchars($signup)?>">Sign your school up</a>
  </div>
</section>

<!-- Footer -->
<footer>
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <div class="navbar-brand mb-2 d-block">SmartSchool<span class="dot text-white-50">.bd</span></div>
        <p class="mb-0">School management software built for Bangladesh schools.</p>
      </div>
      <div class="col-md-4">
        <h6 class="text-white">Product</h6>
        <ul class="list-unstyled m-0">
          <li><a href="#features">Features</a></li>
          <li><a href="#pricing">Pricing</a></li>
          <li><a href="<?=htmlspecialchars($signup)?>">Start free trial</a></li>
          <li><a href="<?=htmlspecialchars($login)?>">Login</a></li>
        </ul>
      </div>
      <div class="col-md-4">
        <h6 class="text-white">Contact</h6>
        <ul class="list-unstyled m-0">
          <li>al.exbru69789@gmail.com</li>
          <li><a href="https://smartschool.bd/signup">smartschool.bd/signup</a></li>
        </ul>
      </div>
    </div>
    <hr class="border-secondary my-4">
    <div class="d-flex flex-wrap justify-content-between gap-2 small">
      <div>© <?=date('Y')?> SmartSchool.bd. All rights reserved.</div>
      <div><a href="<?=base_url('home/privacy')?>">Privacy</a> · <a href="<?=base_url('home/terms')?>">Terms</a></div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
